#-----------------------------------------------------------------------------
#
#  Copyright (c) 2008 by Enthought, Inc.
#  All rights reserved.
#
#-----------------------------------------------------------------------------
""" A rendering toolkit for scalable vector graphics (SVG).
    Part of the Enable project of the Enthought Tool Suite.
"""
