The folder agg24 contains a copy of the Agg-2.4 library.

This code has been adapted from the Matplotlib version of Agg. The original
code is subject to the Anti-Grain Geometry Public License. Modifications by the
Matplotlib development team are subject to the Matplotlib license. Modifications
made as part of the Enable project are subject to the 3-clause BSD license.

Copies of these licenses can be found in the LICENSES directory.

See https://github.com/enthought/enable/pull/288 for more information about the
provenance of this code.
