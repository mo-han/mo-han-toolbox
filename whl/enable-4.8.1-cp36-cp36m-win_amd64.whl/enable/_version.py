# THIS FILE IS GENERATED FROM ENABLE SETUP.PY
version = '4.8.1'
full_version = '4.8.1'
git_revision = 'Unknown'
is_released = True

if not is_released:
    version = full_version
